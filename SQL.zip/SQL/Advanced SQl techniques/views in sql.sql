use sample;
select * from restaurants;
-- DESCRIBE restaurants;

-- 1. create a view
-- drop view if exists v1
create view v1 as (select name,city,cost*rating_count as revenue from restaurants);
select * from v1;

-- 2. create a view for end user
drop view if exists user_view;
create view user_view as (
		select name, city, rating, rating_count as 'orders', 
        cuisine, cost from restaurants);
select * from user_view;


-- 3. Create a view of sweet dishes
-- select distinct(cuisine) from restaurants; to check for sweet cuisine types
create view sweet_view as (select name,cuisine from restaurants where cuisine in ('Sweets', 'Desserts','Bakery','Ice Cream'));
select * from sweet_view;

-- 4. Create a view of top 100 restaurants
create view top_100 as (
		select * from restaurants order by rating_count desc limit 100);
select * from top_100;


-- 5. Create a view of restaurant atleast 100 people visited
create view 100v as (select * from restaurants where rating_count>=100);
select * from 100v;

-- 6. Create a view of top 1000 most expensive restaurants
create view top1000 as (select * from restaurants order by cost desc limit 1000);
select * from top1000;

-- 7. Create a view for top-rated restaurants in each city
create view topR as (
select * from (
select *,rank() over(partition by city order by rating desc) as 'rank' from restaurants) as t
where t.rank=1);

select * from topR;

-- key rule for group by
-- Columns that appear in the SELECT clause must either:
-- Be part of an aggregate function (e.g., COUNT(), SUM(), MAX(), etc.), OR
-- Be included in the GROUP BY clause.
