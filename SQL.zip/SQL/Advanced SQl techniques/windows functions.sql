use sample;
select * from restaurants;

-- 1. create new col containing avg rating of restaurants throughout the dataset
select avg(rating) from restaurants; -- this need to be added as new column 
select *, avg(rating) over() as 'Avg_Rating' from restaurants; -- add new col at the end  
-- select *, round(avg(rating) over(),2) as 'Avg_Rating' FROM restaurants; -- (round off to 2 decimal places)


-- 2.  create new col containing avg rating count of restaurants throughout the dataset
select *,avg(rating_count) over() as 'Avg_rating_count' from restaurants;

-- 3. create new col containing avg cost of restaurants throughout the dataset
select *, avg(cost) over() as 'Avg_cost' from restaurants;

-- 4.  Create column containing average, min, max of cost,rating,rating_count of restaurants throughout the dataset
select *, 
avg(cost) over() as 'avg_cost',
avg(rating) over() as 'avg_rating',
avg(rating_count) over() as 'avg_rating_count',
min(cost) over() as 'min_cost',
min(rating) over() as 'min_rating',
min(rating_count) over() as 'min_rating_count',
max(cost) over() as 'max_cost',
max(rating) over() as 'max_rating',
max(rating_count) over() as 'max_rating_count'
from restaurants;


-- 5. Create column containing average cost of the city where that specific restaurant is from
select *,avg(cost) over(partition by city) as 'avg_cost' from restaurants;

-- 6. Create column containing average cost of the cuisine which that specific restaurant is serving
select *, avg(cost) over(partition by cuisine) as 'Avg_cost' from restaurants;

-- 7. Create both column together
select * , avg(cost) over(partition by city) as 'Avg_cost_City', avg(cost) over(partition by cuisine) as 'avg_cost_cuisine' from restaurants;

-- 8. List the restaurants whose cost is more than the average cost of the restaurants?
select * from restaurants where cost > (select avg(cost) from restaurants);
select * from (select *, avg(cost) over() as 'avg_cost' from restaurants) as t where t.cost > t.avg_cost; 


-- 9.  List the restaurants whose cuisine cost is more than the average cost?
select * from (select *,avg(cost) over(partition by cuisine) as 'avg_cost' from restaurants) as t where t.cost> t.avg_cost;



