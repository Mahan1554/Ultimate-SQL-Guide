-- When creating a stored procedure or function, the SQL statements inside the block often end with a semicolon (;). However, the SQL interpreter also uses a semicolon to indicate the end of a query. To differentiate between semicolons used within the procedure and the semicolon that marks the end of the entire procedure, you can change the statement delimiter temporarily to something else

-- 1. function to calculate age
drop function if exists CalculateAge;
delimiter //
CREATE FUNCTION CalculateAge(birthDate DATE) RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE age INT;
    SET age = YEAR(CURDATE()) - YEAR(birthDate);
    -- Check if the birthday has occurred this year; if not, subtract 1
    IF MONTH(CURDATE()) < MONTH(birthDate) OR (MONTH(CURDATE()) = MONTH(birthDate) AND DAY(CURDATE()) < DAY(birthDate)) THEN
        SET age = age - 1;
    END IF;
    RETURN age;
END //
delimiter ;
select CalculateAge('1990-10-1') as age;


-- 2. Function to Calculate Tax
drop function if exists CalculateTax;
delimiter //
create function CalculateTax(amount DECIMAL(10,2), tax_rate DECIMAL(5,2)) RETURNS DECIMAL(10,2)
deterministic
begin 
	declare tax decimal(10,2);
    set tax = amount * (tax_rate / 100);
    return tax;
end //
delimiter ;
select CalculateTax(1000.15,18) as tax_amount;


-- 3. categorize age
drop function if exists CategorizeAge;
delimiter //
create function CategorizeAge(age int) returns VARCHAR(20)
deterministic
begin 
declare category varchar(20);
if age<18 then set category='teen';
elseif age between 18 and 25 then set category ='adult';
else set category ='senior';
end if;
return category;
end //
delimiter ;
select CategorizeAge(19);









