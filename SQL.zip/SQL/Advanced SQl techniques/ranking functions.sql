use sample;
select * from restaurants;

-- you always need to use the ORDER BY clause with the RANK() function in SQL.

-- rank every restaurant from most expensive to least
select *, rank() over(order by cost desc) as 'Rank_cost' from restaurants;

-- rank every restaurant from most visited to least visited
select *,  rank() over(order by rating_count desc) as 'visitors' from restaurants;

-- rank every restaurant from most expensive to least  as per their city
SELECT *, RANK() OVER (PARTITION BY city ORDER BY cost DESC) AS "rank" FROM restaurants; -- use partition by before order by

-- dense rank every restaurant from most expensive to least 
select *, dense_rank() over(order by cost desc) as "denserank" from restaurants;

-- row number every restaurant from most expensive to least
select * , row_number() over(order by cost desc) as "Row Number" from restaurants;

-- rank,row number and dense rank
select *, rank() over(order by cost desc) as "rank", dense_rank() over(order by cost desc) as "dense Rank", row_number() over(order by cost desc) as "Row Number" from restaurants;

--  Rank every restaurant from most expensive to least expensive as per their city along with its city [Adilabad - 1, Adilabad - 2]
-- select *, rank() over(partition by city order by cost desc) as 'rank', row_number() over(partition by city order by cost desc) as 'city number' from restaurants;
select *, concat(city,' - ' ,row_number() over(partition by city order by cost desc)) as 'rank' from restaurants;

-- find top 5 restaurants of every city as per their revenue
--  the LIMIT clause cannot be used directly inside the RANK(),row_number() or DENSE_RANK() window functions.
select* from (
select name,city,rating_count* cost as "revenue", row_number() over(partition by city order by rating_count*cost desc) as "Row_Number" from restaurants) as t
where t.Row_Number<=5;

-- find top 5 restaurants of every cuisine as per their revenue
select* from (
select name,cuisine,rating_count* cost as "revenue", row_number() over(partition by cuisine order by rating_count*cost desc) as "Row_Number" from restaurants) as t
where t.Row_Number<=5;

