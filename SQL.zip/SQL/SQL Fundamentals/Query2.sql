use employees;
select * from Employees;

-- Case statement
select name, 
case department
when 'sales' then 'sales team'
else 'other'
end as team from Employees;
/*
The CASE statement in the query is used to create a new column (team) based on the 
value of the department column. It categorizes departments into 'sales team' or
 'other' based on the specified condition.
*/

-- example-2
select name,
case department
when 'sales' then 'sales-team'
when 'marketing' then 'marketing-team'
end as team from Employees;

-- exmaple-3
select name,age,
case 
when age>=20 and age<=30  then 'young'
when age>30 and age<=40 then 'Adult'
when age>40 then 'middle-aged'
end as category from Employees order by age;



-- example -4 (nested case)
select name,age,department,
case 
when age<=30 then 
case
when department='sales' then 'Jr.Sales'
else 'Jr'
end 
else 'Sr'
end as Seniority from Employees;



-- example -5 
select name,department,
case 
when department is null then 'No department assigned'
else department
end as dep_status
from Employees;