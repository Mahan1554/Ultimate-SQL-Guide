use employees;

create table if not exists student(
Name varchar(50),
Rollno int primary key,
branch char(3),
course varchar(10),
JoiningDate  date
);

select * from student;

-- insert in single row
insert into student(name,rollno,branch,course,joiningdate) -- order to be inserted
values ('Mahan',260,'ECE','AC','2023-1-1');
select * from student;

-- insert multiple rows
insert into student(name,rollno,branch,course,joiningdate)
values 
('Arjit',257,'ECE','CNA','2022-8-1'),
('Sahan',207,'CSE','ToC','2024-8-1'),
('Jithendra',275,'ECE','CNA','2022-8-1'),
('Ashish',267,'ECE','ONE','2024-1-1'),
('Manoj',200,'ECE','RANAC','2023-1-1'),
('Jogo',235,'ECE','RANAC','2023-8-1');

select * from student; -- order by joiningdate;

-- insert partial data
insert into student(name,rollno,joiningdate) 
values ('Takashi',100,'2024-1-1'); -- remaining values are set to null
select * from student;



-- Adding  current date and default values
create table if not exists ExampleTable(
name varchar(10) not null,
ID serial primary key,
hireDate timestamp default current_timestamp,
status varchar(10) default 'active'
);

insert into exampletable (name) 
values ('polo'); -- takes remaining values as default
select * from ExampleTable;

insert into exampletable(name,status)
values
 ('mahan','inactive'),
('sahan','inactive');
select * from exampletable;

