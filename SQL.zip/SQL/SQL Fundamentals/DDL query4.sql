use employees;
CREATE TABLE People (
    person_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    age INT,
    city VARCHAR(50));

-- Insert sample data into the table
INSERT INTO People (first_name, last_name, age, city)
VALUES 
    ('John', 'Doe', 30, 'New York'),
    ('Jane', 'Smith', 25, 'Los Angeles'),
    ('Michael', 'Johnson', 40, 'Chicago'),
    ('Emily', 'Brown', 35, 'Houston'),
    ('David', 'Jones', 28, 'San Francisco'),
    ('Sarah', 'Davis', 32, 'Seattle'),
    ('Robert', 'Wilson', 45, 'Boston'),
    ('Jennifer', 'Martinez', 27, 'Miami'),
    ('William', 'Taylor', 38, 'Atlanta'),
    ('Jessica', 'Anderson', 33, 'Dallas'),
    ('Daniel', 'Thomas', 29, 'Philadelphia'),
    ('Maria', 'Jackson', 42, 'Phoenix'),
    ('James', 'White', 31, 'Denver'),
    ('Elizabeth', 'Harris', 36, 'Austin'),
    ('Christopher', 'Clark', 39, 'San Diego'),
    ('Amanda', 'Lewis', 26, 'Portland'),
    ('Matthew', 'Walker', 34, 'Detroit'),
    ('Ashley', 'Allen', 37, 'Las Vegas'),
    ('Joseph', 'Young', 41, 'Nashville'),
    ('Stephanie', 'Scott', 24, 'Orlando');
select * from People;


-- update  age   based on primary key
update people
set age=100
where person_id=2;
select * from People; -- we select the row to be updated based on primary key or any unique identifier


-- update city  based on name (this is not a primary key so error 1175 is encountered)
SET SQL_SAFE_UPDATES = 0; -- Disable Safe Update Mode Temporarily
UPDATE people
SET city = 'New York'
WHERE last_name = 'Johnson' AND first_name = 'Michael';
select * from people; 


-- update ages of people less than 30 to 30
update people
set age =30
where age<30;
select * from people;


-- increment the age by 1 of people from los angeles
update people
set age=age +1
where city='los angeles';
select * from people;

update people
set first_name='mahan' , last_name='bhimireddy'
where person_id=7;
select * from people;
