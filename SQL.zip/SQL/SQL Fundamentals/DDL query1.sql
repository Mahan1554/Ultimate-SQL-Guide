drop table if exists Emp100;
create table Emp100(
EmpID int,
name varchar(50)not null,
age int check (age>=18),
department varchar(50)
);

select * from EMp100;

-- Add new column
alter table Emp100 add column mail varchar(50);
select * from Emp100;

alter table emp100 rename column EMpID to ID; -- renaming the column
select * from Emp100;

-- drop the column
alter table emp100 drop column mail;
select * from emp100;

-- setting default col values 
ALTER TABLE emp100 ADD COLUMN marital_status VARCHAR(255) DEFAULT 'single';
select * from emp100;






