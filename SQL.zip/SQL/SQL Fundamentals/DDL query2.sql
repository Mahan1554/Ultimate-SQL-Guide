-- 1. Primary key
create table if not exists Emp101(
EmpID int primary key, -- ID is the primary key (only one primary key per table)
EmpName varchar(50),
Department varchar(50)
);
select * from emp101;


-- 2. Composite Key (multiple cols to make primary key)
create table if not exists Orders(
orderID serial,
customerID int,
orderdate date,
primary key(orderID,customerID)
);
select * from orders;


-- 3. Foreign Key 
-- Creating the "departments" table
CREATE TABLE departmentsfff (
    department_id INT PRIMARY KEY,
    department_name VARCHAR(100)
);
-- Creating the "employees" table with a foreign key to "departments"
CREATE TABLE employeesfff (
    employee_id INT PRIMARY KEY,
    employee_name VARCHAR(100),
    department_id INT,
    FOREIGN KEY (department_id) REFERENCES departmentsfff(department_id)
);
select * from employeesfff;


-- unique constraint 
create table if not exists Emp999(
EmpID int primary key, -- ID is the primary key (only one primary key per table)
EmpName varchar(50),
Department varchar(50),
email varchar(50) unique -- takes unique values for email column
);
select * from emp999;



-- unique  constraint as composite key (combination of 2 cols should be unique)
create table if not exists Emp998(
EmpID int primary key, 
EmpName varchar(50),
mailID varchar(50),
phone int,
unique (phone,mailID)
);
select * from emp998;




