use employees;   -- to use the employees database
select * from Employees;  -- select all attributes from the Employees table
-- select * from employees.Employees; (other way of writing)

select name,age from Employees;  -- selects only name, age cols from Employees table
select age,name  from Employees;

select name as EmpName from Employees; -- changes name to EmpName while selecting (a temporary name used for display purposes in the result set. It does not change the actual column name in the Employees table.)
select name as EmpName, age as EmpAge from Employees;

select * from Employees where age>30; -- get details of employees whose age>30
select * from Employees where age>=30 and department='Sales'; 

select * from Employees where age>30 and age<40; 
select * from Employees where age between 30 and 40; -- same 

select * from Employees where department='Sales' or department='Marketing'; # select both sales nad marketing emp details
select * from Employees where department in ('Sales','Marketing'); -- same 
select * from Employees where department not in ('Sales','Marketing'); -- gives the rest

select * from Employees where name like 'j%'; -- get all the details of emps whose name starts with j

select * from Employees where department is null;
select * from Employees where department is not null;
select * from Employees where department is not null and age is not null;

select * from Employees where (department in ('Sales','Marketing')) and age>30; 

select * from Employees limit 5; -- gives first 5 rows
select * from Employees limit 5 offset 5; -- gives the limit no. of rows from the offset value (starts from 6 to 10)
select * from Employees where department='Sales' limit 5;

select * from Employees order by age; -- sorts the data by age (default ascending order)
select * from Employees order by age asc;
select * from Employees order by age desc;

select * from Employees order by age, employee_id; -- first sorts by age, then IDs of same age grp are sorted





