-- Creating basic table 
drop table if exists Emp;
create table Emp( 
Emp_ID INT,
Name VARCHAR(50),
Age INT,
Department VARCHAR(50)
);
select * from Emp;


-- Table with constraints
create table Emp1(
Emp_ID INT,
Name Varchar(50) not null,
age INT check (age>=18),
department varchar(50) 
);
select * from Emp1;


-- Another Example
create table Emp2(
Emp_ID serial, -- gives serial values from 1
Name Varchar(50) not null,
age INT check (age>=18),
department varchar(50),
hire_date date
);
select * from Emp2;





