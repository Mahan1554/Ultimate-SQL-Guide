use sample;
select * from data;
select product_tag from sample.data;

-- find the avg rating of products
select avg(rating) as avg_rating from data;

-- find the brand names  with a rating higher than the avg rating
select brand_name from data where rating> (select avg(rating) as avg_rating from data); 
-- first subquery is executed then the main query 

-- more optimum  way for above query
SELECT brand_name
FROM data
GROUP BY brand_name
HAVING AVG(rating) > (SELECT AVG(rating) FROM data);

-- retrieve the product names along with the avg rating of products
select product_name,avg(rating) from data group by product_name;

-- retrieve the product names along with avg rating rating of all products
SELECT product_name, rating, (SELECT AVG(rating) FROM data) AS avg_rating
FROM data;

-- find the total rating  count of products for each brand compared to the overall average rating count
select brand_tag, sum(rating_count), (select avg(rating_count) from data) as avg_rating_count from data group by brand_tag;

-- another way
select brand_name ,
( select sum(rating_count) from data where brand_name=d.brand_name)
from (select distinct brand_name from data) as d;






