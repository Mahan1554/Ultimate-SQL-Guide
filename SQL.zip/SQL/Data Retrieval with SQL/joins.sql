-- joins are used to connect multiple tables 
select * from users.users_2021;
select * from users.users_2022;
select * from users.users_2023;

-- 1. INNER JOIN (get only common data based on a matching condition between two tables)

-- User 2021 & 2022
select * from users.users_2021 as t_2021 inner join users.users_2022 as t_2022 on t_2021.UserID = t_2022.UserID;
select * from users.users_2022 as t_2022 inner join users.users_2021 as t_2021 on t_2021.UserID = t_2022.UserID;

-- User 2022 & 2023
select * from users.users_2022 as t_2022 inner join users.users_2023 as t_2023 on t_2022.UserID = t_2023.UserID;
select * from users.users_2023 as t_2023 inner join users.users_2022 as t_2022 on t_2022.UserID = t_2023.UserID;

-- User 2021 & 2023
select * from users.users_2021 as t_2021 inner join users.users_2023 as t_2023 on t_2021.UserID = t_2023.UserID;
select * from users.users_2023 as t_2023 inner join users.users_2021 as t_2021 on t_2021.UserID = t_2023.UserID;

-- user 2021, 2022 and 2023
select * from users.users_2021 as t_2021 inner join users.users_2022 as t_2022 on t_2021.UserID = t_2022.UserID
	inner join users.users_2023 as t_2023 on t_2023.UserID = t_2021.UserID; -- or on t_2023.UserID = t_2022.UserID
    

-- 2.LEFT OUTER JOIN (or LEFT JOIN)
-- Returns all records from the left table (table1), and the matched records from the right table (table2). 
-- If there is no match, the result is NULL from the right table.

select * from users.users_2021 as t_2021 left join users.users_2022 as t_2022 on t_2021.UserID = t_2022.UserID;
select * from users.users_2023 as t_2023 left join users.users_2021 as t_2021 on t_2021.UserID = t_2023.UserID;

-- 3.RIGHT OUTER JOIN (or RIGHT JOIN): 
-- Returns all records from the right table (table2), and the matched records from the left table (table1).
-- If there is no match, the result is NULL from the left table.

select * from users.users_2021 as t_2021 right join users.users_2022 as t_2022 on t_2021.UserID = t_2022.UserID;
select * from users.users_2023 as t_2023 right join users.users_2021 as t_2021 on t_2021.UserID = t_2023.UserID;


-- 4. FULL OUTER JOIN (or FULL JOIN): 
SELECT *
FROM users.users_2021 AS t_2021
full JOIN users.users_2022 AS t_2022
ON t_2021.UserID = t_2022.UserID;

-- Each type of outer join helps to include unmatched rows from one or  both tables in the result set, 
-- providing flexibility in how you retrieve and display data.


-- 5.CROSS JOIN: 
-- Returns the Cartesian product of the two tables. Each row from the first table is
-- combined with each row from the second table. This type of join does not require a condition.
SELECT *
FROM users.users_2021 AS t_2021
cross JOIN users.users_2022 AS t_2022;


-- 6. SELF JOIN: 
-- Joins the table with itself.
-- This can be useful for querying hierarchical data or comparing rows within the same table.
SELECT *
FROM users.users_2021  t_2021_1
inner JOIN users.users_2021  t_2021_2;
-- on t_2021_1.UserID = t_2021_2.UserID;


-- 7. union (no duplicates)
SELECT userID, Name
FROM users.users_2021
UNION 
SELECT userID, Name
FROM users.users_2022;

-- 8. union all (duplicates allowed)
SELECT userID, Name
FROM users.users_2021
UNION all
SELECT userID, Name
FROM users.users_2022;