use sample;
select * from data;

-- find the names of unique brands
select distinct brand_tag from data;

-- find the number of unique brands
select count(distinct(brand_tag)) from data;

-- find the number of products in each brand
select brand_tag, count(product_tag) from data group by brand_tag; -- GROUP BY brand_tag already ensures that each brand_tag is distinct in the result.

-- find the top 5 brands which have most number of products
select brand_tag,count(product_tag) as "No of products" from data group by brand_tag order by 'No of products' desc limit 5;

-- find the top 5 brands which sold the most number of products ( we use number of people rated as reference to number of people bought)
select brand_tag,sum(rating_count) from data group by brand_tag order by count(rating_count) desc limit 5;

-- find the top5 most expensive brands based on their discounted price
select brand_tag,avg(discounted_price) from data group by brand_tag order by avg(discounted_price) desc limit 5;

-- find the top5 least expensive brands based on their discounted price
select brand_tag,avg(discounted_price) from data group by brand_tag order by avg(discounted_price) asc limit 5;

-- top 10 best selling product categories
select product_tag,sum(rating_count) from data group by product_tag order by sum(rating_count) desc limit 10;

-- top 10 brands which gives maximum discount
select brand_tag,avg(discount_percent) from data group by brand_tag order by avg(discount_percent) desc limit 10;

-- top 5 most expensive product categories
select  product_tag,avg(discounted_price) from data group by product_tag order by avg(discounted_price) desc limit 5;

-- brand report card
select brand_tag, 
sum(rating_count) as 'No. of people rated',
 min(marked_price) as 'min marked price', 
 avg(marked_price) as 'avg marked price', 
 max(marked_price) as 'max marked price'
 from data group by brand_tag;

-- top 10 product categories of any brands that are sold the most
select brand_tag ,product_tag, sum(rating_count) from data 
group by brand_tag,product_tag
order by sum(rating_count) desc limit 10;


-- which product category of each brand is sold the most
WITH BrandCategorySales AS (
    SELECT
        brand_name,
        product_tag,
        SUM(rating_count) AS total_sales
    FROM
        data
    GROUP BY
        brand_name, product_tag
),
RankedBrandCategories AS (
    SELECT
        brand_name,
        product_tag,
        total_sales,
        ROW_NUMBER() OVER (PARTITION BY brand_name ORDER BY total_sales DESC) AS sales_rank
    FROM
        BrandCategorySales
)
SELECT
    brand_name,
    product_tag,
    total_sales
FROM
    RankedBrandCategories
WHERE
    sales_rank = 1;


-- list top 5 brands which has sold most number of t shirts
select brand_tag, sum(rating_count) from data where product_tag='tshirts' group by brand_tag order by sum(rating_count) desc limit 5;

-- most popular product name listed on data set
select product_name,count(product_name) from data group by product_name order by count(product_name) desc limit 10;

-- number of products sold for every rating
select rating,count(rating) from data group by rating order by rating asc;

-- number of nike products sold for every rating 
select rating,count(rating) from data where brand_tag='nike' group by rating order by rating asc;

-- number of products sold for every rating in tshirt category
select rating,count(rating_count) from data where product_tag='tshirts' group by rating order by rating asc;

-- relation between price of t-shirt and its rating wrt people rated
SELECT
    product_name,
    AVG(marked_price) AS avg_price,
    AVG(rating) AS avg_rating,
    SUM(rating_count) AS total_ratings
FROM
    data
WHERE
    product_tag = 'tshirts'
GROUP BY
    product_name
ORDER BY
    total_ratings DESC;

-- find the brand with the highest average rating among products with a discounted price greateer than 5000
select brand_tag,avg(rating) from data where discounted_price>5000 group by brand_tag order by avg(rating) desc;


