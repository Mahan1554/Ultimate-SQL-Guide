select * from sample.restaurants;

-- Which restaurant in Abohar is visited by the least number of people? (we will calculate based on rating_count)
select name,rating_count from sample.restaurants where city='abohar' and rating_count<= all(select rating_count from sample.restaurants where city='abohar');

-- or  (preferred)
SELECT name,rating_count
FROM sample.restaurants
WHERE city = 'Abohar' AND rating_count = (
    SELECT MIN(rating_count)
    FROM sample.restaurants
    WHERE city = 'Abohar'
);


-- Which restaurant has generated maximum revenue all over India
select name, rating_count*cost  from sample.restaurants where rating_count*cost=(select max(rating_count*cost) from sample.restaurants);


-- How many restaurants are having a rating more than the average rating?
select count(id) from sample.restaurants where rating>(select avg(rating) from sample.restaurants);

--  Which restaurant of Delhi has generated the most revenue
select name,cost*rating_count from sample.restaurants where city='delhi' and cost*rating_count=(select max(cost*rating_count) from sample.restaurants where city='delhi');


-- Which restaurant chain has the maximum number of restaurants? 
-- In SQL, the COUNT() function is performed after the GROUP BY operation
SELECT name, COUNT(name) AS no_of_chains
FROM sample.restaurants
GROUP BY name
ORDER BY no_of_chains DESC
LIMIT 10;

-- Which restaurant chain has generated maximum revenue?
select name,sum(cost*rating_count) as total_revenue from sample.restaurants group by name order by sum(cost*rating_count) desc limit 10;

--  Which city has the maximum number of restaurants?
select city,count(name) as NumOfRestaurants from sample.restaurants group by city order by NumOfRestaurants desc limit 10;


-- Which city has generated maximum revenue all over India?
select city, sum(cost*rating_count) as revenue from sample.restaurants group by city order by revenue desc limit 10; 


--  List 10 least expensive cuisines?
select cuisine, avg(cost) from sample.restaurants group by cuisine order by avg(cost) asc limit 10;

-- List 10 most expensive cuisines?
select cuisine, avg(cost) from sample.restaurants group by cuisine order by avg(cost) desc limit 10;


--  What city has Biryani as the most popular cuisine?
SELECT city, AVG(rating) AS avg_rating, COUNT(*) AS restaurants
FROM sample.restaurants
WHERE cuisine = 'Biryani'
GROUP BY city
ORDER BY restaurants DESC, avg_rating DESC
LIMIT 10;


-- List top 10 unique restaurants with unique names throughout the dataset as per maximum revenue (Single restaurant with that name)
SELECT name, SUM(cost * rating_count) AS revenue
FROM sample.restaurants
GROUP BY name
HAVING COUNT(name) = 1
ORDER BY revenue DESC
LIMIT 10;

