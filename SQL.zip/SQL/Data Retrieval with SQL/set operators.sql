DROP DATABASE IF EXISTS users;
CREATE DATABASE users;

CREATE TABLE IF NOT EXISTS users.users_2021  (UserID INT PRIMARY KEY, Name VARCHAR(50));
CREATE TABLE IF NOT EXISTS users.users_2022  (UserID INT PRIMARY KEY, Name VARCHAR(50));
CREATE TABLE IF NOT EXISTS users.users_2023  (UserID INT PRIMARY KEY, Name VARCHAR(50));

INSERT INTO users.users_2021 (UserID, Name) VALUES (1, 'Ashish'), (2, 'Laura'), (7, 'Prakash');
INSERT INTO users.users_2022 (UserID, Name) VALUES (1, 'Ashish'), (2, 'Laura'), (3, 'Charlie'), (4, 'Grace');
INSERT INTO users.users_2023 (UserID, Name) VALUES (1, 'Ashish'), (2, 'Laura'), (3, 'Charlie'), (4, 'Grace'), (5, 'Henry');

select * from users.users_2021;
select * from users.users_2022;
select * from users.users_2023;


-- UNION  (for different select statements(tables)) | remove duplicates
select * from users.users_2021 union select * from users.users_2022;
select * from users.users_2022 union select * from users.users_2021;
select * from users.users_2021 union select * from users.users_2023;
select * from users.users_2022 union select * from users.users_2023;
select * from users.users_2021 union select * from users.users_2022 union select * from users.users_2023;


-- UNION ALL | Don't remove duplicates
select * from users.users_2021 union all select * from users.users_2022;
select * from users.users_2022 union all select * from users.users_2021;
select * from users.users_2021 union all select * from users.users_2023;
select * from users.users_2022 union all select * from users.users_2023;
select * from users.users_2021 union all select * from users.users_2022 union all select * from users.users_2023;
select * from users.users_2021 union all select * from users.users_2022 union select * from users.users_2023; -- important


-- EXCEPT (A-B)| Show all the data of dominating table that is not there is other table
select * from users.users_2021 except select * from users.users_2022;
select * from users.users_2022 except select * from users.users_2021;
select * from users.users_2021 except select * from users.users_2023;
select * from users.users_2023 except select * from users.users_2021;
select * from users.users_2021 except select * from users.users_2022 except select * from users.users_2023;
select * from users.users_2023 except select * from users.users_2022 except select * from users.users_2021;

-- INTERSECT | Showing the common data
select * from users.users_2021 intersect select * from users.users_2022;
select * from users.users_2022 intersect select * from users.users_2023;
select * from users.users_2021 intersect select * from users.users_2023;
select * from users.users_2021 intersect select * from users.users_2022 intersect select * from users.users_2023;



-- 1. List the new users added in 2022
select * from users.users_2022 except select * from users.users_2021;

-- 2. List the new users added in 2023
select * from users.users_2023 except select * from users.users_2022;

-- 3. List the users who left us
select * from users.users_2021 except select * from users.users_2022 except select * from users.users_2023;

-- 4. List all the users that are there throughout the database for year 2021 & 2022
select * from users.users_2022 union select * from users.users_2021;

-- 5. List all the users that are there throughout the database
select * from users.users_2021 union select * from users.users_2022 union select * from users.users_2023;

-- 6. List the users that are there with us from last 3 years
select * from users.users_2021 intersect select * from users.users_2022 intersect select * from users.users_2023;

-- 7. List the all the users except that users who are there with us from 3 years
select * from users.users_2021 union select * from users.users_2022 union select * from users.users_2023
except
select * from users.users_2021 intersect select * from users.users_2022 intersect select * from users.users_2023;

-- 8. Operators with Join
select * from users.users_2021 as t_2021 left join users.users_2022 as t_2022 on t_2021.UserID = t_2022.UserID;
select * from users.users_2021 as t_2021 right join users.users_2022 as t_2022 on t_2021.UserID = t_2022.UserID;

select * from users.users_2021 as t_2021 left join users.users_2022 as t_2022 on t_2021.UserID = t_2022.UserID
union
select * from users.users_2021 as t_2021 right join users.users_2022 as t_2022 on t_2021.UserID = t_2022.UserID;



