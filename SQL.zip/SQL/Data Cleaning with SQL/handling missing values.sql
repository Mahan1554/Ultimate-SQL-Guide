use sample;
select * from messy_indian_dataset2;

-- select rows with null values (missing values) in any col 
SELECT * 
FROM messy_indian_dataset2 
WHERE name IS NULL 
   OR age IS NULL 
   OR gender IS NULL 
   OR email IS NULL 
   OR phone_number IS NULL 
   OR city IS NULL 
   OR state IS NULL 
   OR purchase_amount IS NULL 
   OR purchase_date IS NULL;
   
-- select rows containing no null values
SELECT * 
FROM messy_indian_dataset2 
WHERE name IS  not NULL 
   and age IS not NULL 
   and gender IS not NULL 
   and email IS not NULL 
   and phone_number IS not NULL 
   and city IS not NULL 
   and state IS  not NULL 
   and purchase_amount IS not NULL 
   and purchase_date IS not NULL;
   
   
-- Saving table without null values
create table if not exists nonull_table as
	select * from messy_indian_dataset 
		where name is not null and age is not null and gender is not null and email is not null and city is not null and
		phone_number is not null and state is not null and purchase_amount is not null and purchase_date is not null;
select * from nonull_table;


-- Filling all missing age with specific values (fill with 0)
SET SQL_SAFE_UPDATES = 0; -- disable safe update mode
update messy_indian_dataset2 set age = coalesce(age,0);
select * from messy_indian_dataset2;


-- Filling nulls with specific values
update messy_indian_dataset2
set
	name = coalesce(name, 'Unknown'),
    gender = coalesce(gender, 'Unknown'),
    email = coalesce(email, 'Unknown'),
    phone_number = coalesce(phone_number, 'Unknown'),
    state = coalesce(state, 'Unknown'),
    city=coalesce(city,'unknown'),
    purchase_date = coalesce(purchase_date, '2023-01-01'),
    purchase_amount=coalesce(purchase_amount,0.0);
select * from messy_indian_dataset2;


 -- Filling null amount with average amount values
UPDATE messy_indian_dataset2
SET purchase_amount = (select avg_amount from (SELECT AVG(purchase_amount) as avg_amount FROM messy_indian_dataset2) as subquery)
WHERE purchase_amount is null;
select * from messy_indian_dataset2;

-- or another method
SELECT AVG(purchase_amount) as avgg FROM messy_indian_dataset2;
UPDATE messy_indian_dataset2
SET purchase_amount = @avgg
WHERE purchase_amount is null;
select * from messy_indian_dataset2;
 

-- Filling null city with most frequent city (now null is unknown bcoz we set that later)
UPDATE messy_indian_dataset2
SET city = (select city as max_city from (select city,count(city) as num from messy_indian_dataset2 group by city) as t where t.num=3)
WHERE city='unknown';
select * from messy_indian_dataset2;












