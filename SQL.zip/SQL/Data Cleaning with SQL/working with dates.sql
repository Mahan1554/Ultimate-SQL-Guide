use saMPLE;
select * from messy_indian_dataset3;

-- add new column for day, month  , year
alter table messy_indian_dataset3 
add column day int,
add column month int,
add column year int;
select * from messy_indian_dataset3;

-- Update the new columns with the extracted day, month, and year values
update messy_indian_dataset3
	set day   = DAY(purchase_date),
		month = MONTH(purchase_date),
		year  = YEAR(purchase_date);
select * from messy_indian_dataset3;


-- Add a new column for the day of the week & save day name there
alter table messy_indian_dataset3
	add column day_of_week varchar(10);

update messy_indian_dataset3
	set day_of_week = DAYNAME(purchase_date);
select * from messy_indian_dataset3;


-- Add a new column for the name of the month & save day name there
alter table messy_indian_dataset3
	add column month_name varchar(10);

update messy_indian_dataset3
	set month_name = MONTHNAME(purchase_date);
select * from messy_indian_dataset3;




