use sample;
select * from messy_indian_dataset3;

-- can also be done by removing values more than taking 2x of avg

-- finding outliers based of z-scores
select *, 
	ABS(purchase_amount - avg(purchase_amount) over()) / STDDEV(purchase_amount) OVER() as 'z_score'
from messy_indian_dataset3;

-- Remove outliers based on specific Z-Score
select * from
	(
		select *, 
			ABS(purchase_amount - avg(purchase_amount) over()) / STDDEV(purchase_amount) OVER() as 'z_score'
		from messy_indian_dataset
	) as sub_table where sub_table.z_score < 3;