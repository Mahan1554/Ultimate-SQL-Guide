use sample;
select * from messy_indian_dataset2;

-- original query
SELECT id, name, city, purchase_amount
	FROM messy_indian_dataset2
		WHERE city = 'Mumbai' AND purchase_amount > 1000 AND gender = 'Male';

-- simplified using CTE 
WITH D1 AS (
    SELECT id, name, city, purchase_amount
    FROM messy_indian_dataset2
    where city = 'Mumbai' AND gender = 'Male'
)
SELECT * from D1 where purchase_amount > 1000;


-- Example 2
with highPurchase as (
SELECT id, name, city, purchase_amount
    FROM messy_indian_dataset2
    where purchase_amount>1000
)
SELECT * from highpurchase where city='mumbai';


-- example 3
with AvgPurchasePerCity as (
SELECT city, avg(PURCHASE_amount) as AvgPurchase
    FROM messy_indian_dataset2
    group by city
)
select city, AvgPurchase from avgPurchasepercity limit 10;



-- example 4
with preAggregated as (
select city,sum(purchase_amount) as Total_Purchase,count(*) as Num_Purchase
from messy_indian_dataset2
group by city
)
select city , num_purchase,Total_purchase from preaggregated;


-- example 5
with 
totalPurchase as (
select city,sum(purchase_amount) as Total_Purchase
from messy_indian_dataset2
group by city
),
AvgPurchase as (
select city,avg(purchase_amount) as Avg_purchase
from messy_indian_dataset2
group by city
)
select * from totalPurchase tp join avgpurchase ap on tp.city=ap.city;







